package com.tansci.service.system;

/**
 * @ClassName： TaskRegisterService.java
 * @ClassPath： com.tansci.service.system.TaskRegisterService.java
 * @Description： 任务注册器
 * @Author： tanyp
 * @Date： 2022/2/25 10:05
 **/
public interface TaskRegisterService {

    void register();

}
