package wakoo.fun.config;

import java.util.Map;

public class Response {
    private int status;
    private Map<String, Object> data;

    public void setData(int status, Map<String, Object> data) {
        this.status = status;
        this.data = data;
    }

    // 可能还有其他属性和方法...

    // Getter和Setter方法...

}