package wakoo.fun.controller.FaAdminController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.web.bind.annotation.*;
import wakoo.fun.config.UserLoginToken;
import wakoo.fun.controller.CaptchaController.getKaptchaImage;
import wakoo.fun.utils.MsgUtils;
import wakoo.fun.dto.MsgVo;
import wakoo.fun.pojo.FaAdmin;
import wakoo.fun.service.FaAdminService;
import wakoo.fun.utils.TokenUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/api")
@Api(tags = "Admin")
public class FaAdminController {

    @Resource
    private getKaptchaImage asd;
    @Resource
    private FaAdminService faAdminService;

    @ApiOperation(value = "登录")
    @ApiResponses({
            @ApiResponse(responseCode = "500",description = "请联系管理员"),
            @ApiResponse(responseCode = "1000",description = "响应成功")
    })
    @PostMapping("/login")
    public MsgVo login(String userName, String password,HttpServletRequest request,String CaptchaImage) throws Exception {
        String captchaSession = asd.getCaptchaSession(request);
        if (!CaptchaImage.equals(captchaSession)){
            return new MsgVo(MsgUtils.FAILED);
        }
        MsgVo msg=null;
            List<FaAdmin> faAdmins=faAdminService.faAdmin(userName);
        System.out.println(faAdmins.size());
            if (faAdmins.size()!=0){
                if (!faAdmins.get(0).getPassword().equals(password)){
                    msg=new MsgVo(400,"密码错误",null);
                }else {
                    /*登录成功*/
                    String token = TokenUtils.token(userName, password);
                    Boolean aBoolean = faAdminService.UpdToken(token, userName);
                    msg=new MsgVo(MsgUtils.SUCCESS,token);
                }
            }else {
                msg=new MsgVo(MsgUtils.FAILED);
            }
        return msg;
    }

    @ApiOperation(value = "token")
    @ApiResponses({
            @ApiResponse(responseCode = "500",description = "请联系管理员"),
            @ApiResponse(responseCode = "1000",description = "响应成功")
    })
    @UserLoginToken
    @PostMapping("/token")
    public MsgVo login(String token){
        return new MsgVo(MsgUtils.SUCCESS);
    }

}
