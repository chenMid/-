package wakoo.fun.service;

/**
 * 状态码接口
 */
public interface FaAdminCode {
    public int getCode();
    public String getMsg();
}
