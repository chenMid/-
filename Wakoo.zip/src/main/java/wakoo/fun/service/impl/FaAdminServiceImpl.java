package wakoo.fun.service.impl;

import org.springframework.stereotype.Service;
import wakoo.fun.mapper.FaAdminMapper;
import wakoo.fun.pojo.FaAdmin;
import wakoo.fun.service.FaAdminService;

import javax.annotation.Resource;
import java.util.List;
@Service
public class FaAdminServiceImpl implements FaAdminService {

    @Resource
    private FaAdminMapper faAdminMapper;

    @Override
    public List<FaAdmin> faAdmin(String userName) {
        return faAdminMapper.faAdmin(userName);
    }

    @Override
    public Boolean UpdToken(String Token, String userName) {
        return faAdminMapper.UpdToken(Token, userName);
    }

    @Override
    public FaAdmin getFaAdmin(Integer id) {
        return faAdminMapper.getFaAdmin(id);
    }
}
