package wakoo.fun.service;

import wakoo.fun.pojo.FaAdmin;

import java.util.List;

public interface FaAdminService {
    /**
     * 查询指定用户，没有指定用户查询所有
     * @param userName
     * @return
     */
    List<FaAdmin> faAdmin(String userName);

    /**
     * 存储token
     * @param Token
     * @param userName
     * @return
     */
    Boolean UpdToken(String Token,String userName);

    /**
     * 查询指定用户通过id
     * @param id
     * @return
     */
    FaAdmin getFaAdmin(Integer id);

}
