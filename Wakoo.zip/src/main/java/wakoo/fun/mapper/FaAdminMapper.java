package wakoo.fun.mapper;

import org.apache.ibatis.annotations.Param;
import wakoo.fun.pojo.FaAdmin;

import java.util.List;


public interface FaAdminMapper {

    List<FaAdmin> faAdmin(@Param("userName") String userName);

    Boolean UpdToken(@Param("Token") String Token, @Param("userName") String userName);

    Boolean avatar(@Param("id") Integer id, @Param("avatarPath") String avatarPath);

    FaAdmin getFaAdmin(Integer id);

}
